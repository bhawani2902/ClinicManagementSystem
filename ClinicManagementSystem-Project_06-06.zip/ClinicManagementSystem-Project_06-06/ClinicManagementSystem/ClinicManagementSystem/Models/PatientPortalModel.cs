﻿namespace ClinicManagementSystem.Models
{
    public class PatientPortalModel
    {
       public string PatientEmail { get; set; }
      // public long PatientPhoneNo { get; set;}
    }
   
}
