﻿namespace ClinicManagementSystem.Models
{
    public class DoctorPortalViewModel
    {
        public DoctorModel Doctor { get; set; }
        public List<Appointment> Appointments { get; set; }
    }
}
